# -*- coding: utf-8 -*-

from __future__ import unicode_literals

__title__ = "drf-haystack"
__version__ = "1.6.1"
__author__ = "Rolf Haavard Blindheim"
__license__ = "MIT License"

VERSION = __version__
