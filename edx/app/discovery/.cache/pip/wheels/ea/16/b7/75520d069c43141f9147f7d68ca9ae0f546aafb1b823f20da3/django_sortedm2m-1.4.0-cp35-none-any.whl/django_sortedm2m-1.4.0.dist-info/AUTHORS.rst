Author
------

* Gregor Müllegger <gregor@muellegger.de>

Contributors
------------

* Chris Church
* jonny5532
* Sean O'Connor
* Flavio Curella
* Florian Ilgenfritz
* Antti Kaihola
* Mike Knoop
* Marcin Ossowski
* Rubén Díaz
