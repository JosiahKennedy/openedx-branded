# Needed for Django 1.4/1.5 test runner
from .test_softdeletable_model import *
from .test_status_model import *
from .test_timeframed_model import *
from .test_timestamped_model import *
