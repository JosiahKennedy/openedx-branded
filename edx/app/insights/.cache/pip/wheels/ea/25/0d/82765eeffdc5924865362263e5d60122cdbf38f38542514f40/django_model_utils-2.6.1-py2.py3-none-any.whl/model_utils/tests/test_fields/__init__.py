# Needed for Django 1.4/1.5 test runner
from .test_field_tracker import *
from .test_monitor_field import *
from .test_split_field import *
from .test_status_field import *
