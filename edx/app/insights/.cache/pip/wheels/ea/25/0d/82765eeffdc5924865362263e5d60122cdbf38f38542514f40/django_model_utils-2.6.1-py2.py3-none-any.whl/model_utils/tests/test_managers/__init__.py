# Needed for Django 1.4/1.5 test runner
from .test_inheritance_manager import *
from .test_query_manager import *
from .test_status_manager import *
from .test_softdelete_manager import *
