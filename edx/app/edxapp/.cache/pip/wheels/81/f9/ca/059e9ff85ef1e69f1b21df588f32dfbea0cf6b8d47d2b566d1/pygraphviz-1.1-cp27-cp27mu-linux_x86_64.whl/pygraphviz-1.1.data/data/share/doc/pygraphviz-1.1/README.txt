PyGraphviz
----------

PyGraphviz is a Python interface to the Graphviz graph layout and
visualization package.

With PyGraphviz you can create, edit, read, write, and draw graphs using
Python to access the Graphviz graph data structure and layout algorithms.

PyGraphviz is distributed with a BSD license.

Copyright (C) 2006-2011 by 
Aric Hagberg <hagberg@lanl.gov>
Dan Schult <dschult@colgate.edu>
Manos Renieris, http://www.cs.brown.edu/~er/
Distributed with BSD license.     
All rights reserved, see LICENSE.txt for details.
