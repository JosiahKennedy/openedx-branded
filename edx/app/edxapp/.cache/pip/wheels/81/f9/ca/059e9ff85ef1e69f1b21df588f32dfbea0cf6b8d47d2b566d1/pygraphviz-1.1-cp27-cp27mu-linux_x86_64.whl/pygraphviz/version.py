"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.1.dev1952'
__revision__ = '1952'
__date__ = 'Thu Apr 14 11:28:08 2011'

