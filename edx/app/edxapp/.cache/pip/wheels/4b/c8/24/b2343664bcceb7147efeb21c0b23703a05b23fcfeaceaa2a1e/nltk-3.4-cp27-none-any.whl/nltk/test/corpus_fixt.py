# -*- coding: utf-8 -*-
from __future__ import absolute_import

from nltk.corpus import teardown_module
